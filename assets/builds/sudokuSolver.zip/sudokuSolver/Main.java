import java.util.Arrays;

public class Main {
   public static void main(String[] args) {
       /*
       int[][] sudokuGrid = {
               {5, 3, 0, 0, 7, 0, 0, 0, 0},
               {6, 0, 0, 1, 9, 5, 0, 0, 0},
               {0, 9, 8, 0, 0, 0, 0, 6, 0},
               {8, 0, 0, 0, 6, 0, 0, 0, 3},
               {4, 0, 0, 8, 0, 3, 0, 0, 1},
               {7, 0, 0, 0, 2, 0, 0, 0, 6},
               {0, 6, 0, 0, 0, 0, 2, 8, 0},
               {0, 0, 0, 4, 1, 9, 0, 0, 5},
               {0, 0, 0, 0, 8, 0, 0, 7, 9}
       };

        */

       int[][] sudokuGrid = {
               {0, 0, 6, 5, 0, 0, 0, 0, 0},
               {7, 0, 5, 0, 0, 2, 3, 0, 0},
               {0, 3, 0, 0, 0, 0, 0, 8, 0},
               {0, 5, 0, 0, 9, 6, 0, 7, 0},
               {1, 0, 4, 0, 0, 0, 0, 0, 8},
               {0, 0, 0, 8, 2, 0, 0, 0, 0},
               {0, 2, 0, 0, 0, 0, 0, 9, 0},
               {0, 0, 7, 2, 0, 0, 4, 0, 0},
               {0, 0, 0, 0, 0, 7, 5, 0, 0}
       };

       solveSudoku(sudokuGrid);
       if (solve(sudokuGrid) == false) {
           System.out.println("No solution");
       } else {
           System.out.println("Solution:");
           printArray(sudokuGrid);
       }


   }

   public static void solveSudoku(int[][] grid) {
       solve(grid);
   }

   public static boolean solve(int[][] grid) {
       int row = -1;
       int col = -1;
       boolean isGridFull = true;

       // Find the first empty cell in the grid
       for (int i = 0; i < grid.length; i++) {
           for (int j = 0; j < grid[0].length; j++) {
               if (grid[i][j] == 0) {
                   row = i;
                   col = j;
                   isGridFull = false;
                   break;
               }
           }
           if (!isGridFull) {
               break;
           }
       }

       // If the grid is full, the Sudoku puzzle is solved
       if (isGridFull) {
           return true;
       }

       // Try each number from 1 to 9
       for (int num = 1; num <= 9; num++) {
           if (isSafe(grid, row, col, num)) {
               grid[row][col] = num;

               // Recursively solve the Sudoku puzzle
               if (solve(grid)) {
                   return true;
               }

               // If the current number doesn't lead to a solution, backtrack
               grid[row][col] = 0;
           }
       }

       return false;
   }

   public static boolean isSafe(int[][] grid, int row, int col, int num) {
       // Check if the number already exists in the row
       for (int i = 0; i < grid.length; i++) {
           if (grid[i][col] == num) {
               return false;
           }
       }

       // Check if the number already exists in the column
       for (int j = 0; j < grid[0].length; j++) {
           if (grid[row][j] == num) {
               return false;
           }
       }

       // Check if the number already exists in the 3x3 box
       int boxRow = row - row % 3;
       int boxCol = col - col % 3;
       for (int i = 0; i < 3; i++) {
           for (int j = 0; j < 3; j++) {
               if (grid[boxRow + i][boxCol + j] == num) {
                   return false;
               }
           }
       }

       return true;
   }

   public static void printArray(int[][] array) {
       for (int i = 0; i < array.length; i++) {
           for (int j = 0; j < array[i].length; j++) {
               System.out.print(array[i][j] + " ");
           }
           System.out.println();
       }
   }
}
/*
import java.sql.Array;
import java.util.Arrays;

public class Main {
   public static void main(String[] args) {
       System.out.println("Hello world!");

       int[][] grid = {
               {5, 3, 0, 0, 7, 0, 0, 0, 0},
               {6, 0, 0, 1, 9, 5, 0, 0, 0},
               {0, 9, 8, 0, 0, 0, 0, 6, 0},
               {8, 0, 0, 0, 6, 0, 0, 0, 3},
               {4, 0, 0, 8, 0, 3, 0, 0, 1},
               {7, 0, 0, 0, 2, 0, 0, 0, 6},
               {0, 6, 0, 0, 0, 0, 2, 8, 0},
               {0, 0, 0, 4, 1, 9, 0, 0, 5},
               {0, 0, 0, 0, 8, 0, 0, 7, 9}
       };

       solveSudoku(grid);
       printArray(grid);
   }

   public static void solveSudoku(int[][] grid) {
       solve(grid);
   }

   public static boolean solve(int[][] grid) {
       int row = -1;
       int col = -1;
       boolean isGridFull = true;

       // Find first empty cell
       for (int i = 0; i < grid.length; i++) {
           // Loop for each row in the grid
           for (int j = 0; j < grid[0].length; j++) {
               // Loop for each column in the grid
               if (grid[i][j] == 0) {
                   // If the cell is empty (contains 0), set the target row and column
                   row = i;
                   col = j;
                   isGridFull = false;
                   // Set isGridFull to false indicating that the grid is not full
                   break;
                   // Break the loop
               }
           }
           if (!isGridFull) {
               break;
               // Break the second loop
           }
       }

       // If the grid is full, return true indicating that we have solved the Sudoku puzzle
       if (isGridFull) {
           return true;
       }

       // Try each number from 1 to 9
       for (int num = 0; num < 9; num++) {
           // Loop for each number from 1 to 9
           if (isSafe(grid, row, col, num)) {
               // If the number is safe to be placed at the target cell
               grid[row][col] = num; // Try the number in the target cell

               // Use recursion to solve the Sudoku puzzle
               if (solve(grid)) {
                   // If true is returned, the number worked, so return true to continue the recursion
                   return true;
               }

               // If the current number doesn't lead to a solution, backtrack
               grid[row][col] = 0;
               // Reset the target cell to 0 (empty)
           }
       }

       return false;
   }

   public static boolean isSafe(int[][] grid, int row, int col, int num) {
       // Check if the number already exists in the row
       for (int i = 0; i < grid.length; i++) {
           if (grid[i][col] == num) {
               // If the number already exists in the same column, return false
               return false;
           }
       }

       // Check if the number already exists in the column
       for (int j = 0; j < grid[0].length; j++) {
           if (grid[row][j] == num) {
               // If the number already exists in the same row, return false
               return false;
           }
       }

       // Check if the number already exists in the 3x3 box
       int boxRow = row - row % 3;
       int boxCol = col - col % 3;
       // Subtracting the remainder from row and col gives the starting row and column location of the 3x3 box
       for (int i = 0; i < 3; i++) {
           for (int j = 0; j < 3; j++) {
               // Check within the constraints of the 3x3 box
               if (grid[boxRow + i][boxCol + j] == num) {
                   //Checking the relative row and column location to the starting row and column of the 3x3 box
                   return false;
                   // If true, the same number exists in the 3x3 box, so return false
               }
           }
       }

       return true;
   }

   public static void printArray(int[][] array) {
       for (int i = 0; i < array.length; i++) {
           for (int j = 0; j < array[i].length; j++) {
               System.out.print(array[i][j] + " ");
           }
           System.out.println();
       }

   }
}
   */