import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        List<String> wordsArray = new ArrayList<>();
        System.out.println();
        Scanner scanner = new Scanner(System.in);
        try {
            File words = new File("/Users/natewarneck/Desktop/Folder all (SUPER folder of all)/Desktop - 2021-Grade9-NateWarneck/Folder/School/Grade 11/Computer Science/Coding Projects/Challenges/Java/Hangman/src/words");
            Scanner myReader = new Scanner(words);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                wordsArray.add(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        int arrayLength = wordsArray.size();
        int randInt = (int) (Math.random() * arrayLength);
        String currentWord = wordsArray.get(randInt);
        //System.out.println(currentWord);
        int amountOfLetters = currentWord.length();
        char[] fullWord = new char[amountOfLetters];
        List<Character> lettersUsed = new ArrayList<>();
        char letterAttempt;

        for (int i = 0; i < amountOfLetters; i++) {
            fullWord[i] = '_';
        }

        System.out.println("The amount of letters is " + amountOfLetters + ".\n");

        for (int i = 0; i < 10; ) {
            System.out.println("\n");
            for (int x = 0; x < amountOfLetters; x++) {
                System.out.print(" " + fullWord[x] + " ");
            }
            System.out.println("\n");
            System.out.print("Enter letter: ");
            letterAttempt = scanner.nextLine().charAt(0);
            boolean found = false;
            for (int x = 0; x < amountOfLetters; x++) {
                if (currentWord.charAt(x) == letterAttempt) {
                    fullWord[x] = letterAttempt;
                    found = true;
                }
            }
            if (!found) {
                System.out.println("That letter is not in the word.");
                if (!lettersUsed.contains(letterAttempt)) {
                    lettersUsed.add(letterAttempt);
                    i++;
                }
            }
            System.out.println("You have " + (10 - i) + " guesses left.");
            if (!lettersUsed.isEmpty()) {
                System.out.print("You have used the letters: ");
                for (Character c : lettersUsed) {
                    System.out.print(c + " ");
                }
            }
            if (Arrays.equals(fullWord, currentWord.toCharArray())) {
                System.out.println("\n");
                for (int x = 0; x < amountOfLetters; x++) {
                    System.out.print(" " + fullWord[x] + " ");
                }
                System.out.println("\n");
                System.out.println("Congratulations! You've won!");
                break;
            }
        }
    }
}

